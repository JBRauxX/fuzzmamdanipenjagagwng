/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tuskamoto.menentukan.kelayakan.penjaga.gawang;

import java.util.Scanner;
/**
 *
 * @author root
 */
public class TuskamotoMenentukanKelayakanPenjagaGawang {
int usia,tinggi,respon,skill;

//{batasan rules
//usia muda
public static double muda(double x){
    double myu = 0;
    if(x<=20)
    {
        myu = 1;
    }
    else if(0 <= x && x<= 20)
    {
        myu = (20-x)/20;
    }
    else if(x >= 20)
    {
       myu = 0;
    }
    return myu;
}
//usia menegah
public static double menengah(double x)
{
    double myu = 0;
    if(x <= 18 || x >= 30)
    {
        myu = 0;
    }
    else if(18 <= x && x <= 24)
    {
        myu = (x-18)/6;
    }
    else if(24 <= x && x <= 30)
    {
        myu = (30-x)/6;
    }
    return myu;

}
//usia tua
public static double tua(double x)
{
    double myu = 0;
    if(x <= 28)
    {
        myu = 0;
    }
    else if(28 <= x && x <= 45)
    {
       myu = (x-28)/17;
    }
    else if(x >= 45)
    {
       myu = 1;
    }
    return myu;
}

//tinggibadan pendek
public static double pendek(double x)
{
    double myu = 0;
    if(x <= 0)
    {
        myu = 1;
    }
    else if(0 <= x && x <= 165)
    {
        myu = (165-x)/165;
    }
    else if(x >= 165)
    {
        myu = 0;
    }
    return myu;
}
//tinggibadan sedang
public static double sedang(double x)
{
    double myu = 0;
    if(x <= 163 || x >= 185)
    {
        myu = 0;
    }
    else if(163 <= x && x < 174)
    {
        myu = (x-163)/11;
    }
    else if(174 < x && x <= 185)
    {
        myu = (185-x)/11;
    }
    return myu;
}
//tinggibadan tinggi
public static double tinggi(double x)
{
   double myu = 0;
   if(x <= 180)
   {
       myu = 0;
   }
   else if(180 <= x && x <=205)
   {
       myu = (x-180)/25;
   }
   else if(x >= 205)
   {
       myu = 1;
   }
   return myu;
}
//respon rendah
public static double responRendah(double x)
{
    double myu = 0;
    if(x >= 74)
    {
        myu = 0;
    }
    else if(0 <= x && x <= 74)
    {
        myu = (74-x)/74;
    }
    else if(x <= 0)
    {
        myu = 1;
    }
    return myu;
}
//respon tinggi
public static double responTinggi(double x)
{
    double myu = 0;
    if(x <= 70)
    {
        myu = 0;
    }
    else if(70 <= x && x <= 99)
    {
        myu = (x-70)/29;
    }
    else if(x >= 99)
    {
     myu = 1;
    }
    return myu;
}

//skill rendah
public static double skillRendah(double x)
{
    double myu = 0;
    if(x >= 74)
    {
        myu = 0;
    }
    else if(0 <= x && x <= 74)
    {
        myu = (74-x)/74;
    }
    else if(x <= 0)
    {
     myu = 1;
    }
    return myu;
}
//skill tinggi
public static double skillTinggi(double x)
{
    double myu = 0;
    if(x <= 70)
    {
        myu = 0;
    }
    else if(70 <= x && x <= 99)
    {
        myu = (x-70)/29;
    }
    else if(x >= 99)
    {
     myu = 1;
    }
    return myu;
}
//sampai sini bentuk kurva fuzzy

//proper
public static double zproper(double myu)
{
    double pro;
    pro = (myu*20)+60;
    return pro;
}
//non proper
public static double znonPorper(double myu)
{
    double nopro;
    nopro = (myu*20)+40;
    
    return nopro;
}

public static double min1(double a, double b)
{
        double min1;
           min1 = Math.min(a,b);
        return min1;
}
public static double min2(double c, double d)
{
        double min2;
           min2 = Math.min(c,d);
        return min2;
}
public static double min(double z, double x)
{
        double min;
           min = Math.min(z,x);
        return min;
}

    public static void main(String[] args)
    {
    }

    public double hitunghasil(double usia, double tinggi, double respon, double skill)
    {
        double myumuda, myumenengah, myutua,
                myutinggi, myusedang, myupendek,
                myuresponRendah, myuresponTinggi, myuskillRendah,
                myuskillTinggi, myuproper, myunonPorper;

        myumuda = muda(usia);
        myumenengah = menengah(usia);
        myutua = tua(usia);
        myutinggi = tinggi(tinggi);
        myusedang = sedang(tinggi);
        myupendek = pendek(tinggi);
        myuresponRendah = responRendah(respon);
        myuresponTinggi = responTinggi(respon);
        myuskillRendah = skillRendah(skill);
        myuskillTinggi = skillTinggi(skill);

        
        double min1 = min(myutua,myutinggi);
        double min2 = min(myuresponTinggi,myuskillTinggi);
        double predikat1 = min(min1, min2);
        System.out.println("predikat 1 = "+predikat1);
        
        double min3 = min(myuresponTinggi,myuskillRendah);
        double min4 = min(myutua,myutinggi);
        double predikat2 = min(min3,min4);
        System.out.println("predikat 2 = "+predikat2);
        
        double min5 = min(myutua,myutinggi);
        double min6 = min(myuresponRendah,myuskillTinggi);
        double predikat3 = min(min5,min6);
        System.out.println("predikat 3 = "+predikat3);
        
        double min7 = min(myutua,myutinggi);
        double min8 = min(myuresponRendah,myuskillRendah);
        double predikat4 = min(min7,min8);
        System.out.println("predikat 4 = "+predikat4);
        
        double min9 = min(myutua,myusedang);
        double min10 = min(myuresponTinggi,myuskillTinggi);
        double predikat5 = min(min9,min10);
        System.out.println("predikat 5 = "+predikat5);
        
        double min11 = min(myutua,myusedang);
        double min12 = min(myuresponTinggi,myuskillRendah);
        double predikat6 = min(min11,min12);
        System.out.println("predikat 6 = "+predikat6);
        
        double min13 = min(myutua,myusedang);
        double min14 = min(myuresponRendah,myuskillTinggi);
        double predikat7 = Math.min(min13,min14);
        System.out.println("predikat 7 = "+predikat7);
        
        double min15 = min(myutua,myusedang);
        double min16 = min(myuresponRendah,myuskillRendah);
        double predikat8 = min(min15,min16);
        System.out.println("predikat 8 = "+predikat8);
        
        double min17 = min(myutua,myupendek);
        double min18 = min(myuresponTinggi,myuskillTinggi);
        double predikat9 = min(min17,min18);
        System.out.println("predikat 9 = "+predikat9);
        
        double min19 = min(myutua,myupendek);
        double min20 = min(myuresponTinggi,myuskillRendah);
        double predikat10 = min(min19,min20);
        System.out.println("predikat 10 = "+predikat10);
        
        double min21 = min(myutua,myupendek);
        double min22 = min(myuresponRendah,myuskillTinggi);
        double predikat11 = min(min21,min22);
        System.out.println("predikat 11 = "+predikat11);
        
        double min23 = min(myutua,myupendek);
        double min24 = min(myuresponRendah,myuskillRendah);
        double predikat12 = min(min23,min24);
        System.out.println("predikat 12 = "+predikat12);
        
        double min25 = min(myusedang,myutinggi);
        double min26 = min(myuresponTinggi,myuskillTinggi);
        double predikat13 = min(min25,min26);
        System.out.println("predikat 13 = "+predikat13);
        
        double min27 = min(myumenengah,myutinggi);
        double min28 = min(myuresponTinggi,myuskillRendah);
        double predikat14 = min(min27,min28);
        System.out.println("predikat 14 = "+predikat14);
        
        double min29 = min(myumenengah,myutinggi);
        double min30 = min(myuresponRendah,myuskillTinggi);
        double predikat15 = min(min29,min30);
        System.out.println("predikat 15 = "+predikat15);
        
        double min31 = min(myumenengah,myutinggi);
        double min32 = min(myuresponRendah,myuskillRendah);
        double predikat16 = min(min31,min32);
        System.out.println("predikat 16 = "+predikat16);
        
        double min33 = min(myumenengah,myusedang);
        double min34 = min(myuresponTinggi,myuskillTinggi);
        double predikat17 = min(min33,min34);
        System.out.println("predikat 17 = "+predikat17);
        
        double min35 = min(myumenengah,myusedang);
        double min36 = min(myuresponTinggi,myuskillRendah);
        double predikat18 = min(min35,min36);
        System.out.println("predikat 18 = "+predikat18);
        
        double min37 = min(myumenengah,myusedang);
        double min38 = min(myuresponRendah,myuskillTinggi);
        double predikat19 = min(min37,min38);
        System.out.println("predikat 19 = "+predikat19);
        
        double min39 = min(myumenengah,myusedang);
        double min40 = min(myuresponRendah,myuskillRendah);
        double predikat20 = min(min39,min40);
        System.out.println("predikat 20 = "+predikat20);
        
        double min41 = min(myumenengah,myupendek);
        double min42 = min(myuresponTinggi,myuskillTinggi);
        double predikat21 = min(min41,min42);
        System.out.println("predikat 21 = "+predikat21);
        
        double min43 = min(myumenengah,myupendek);
        double min44 = min(myuresponTinggi,myuresponRendah);
        double predikat22 = min(min43,min44);
        System.out.println("predikat 22 = "+predikat22);
        
        double min45 = min(myumenengah,myupendek);
        double min46 = min(myuresponRendah,myuskillTinggi);
        double predikat23 = min(min45,min46);
        System.out.println("predikat 23 = "+predikat23);
        
        double min47 = min(myumenengah,myupendek);
        double min48 = min(myuresponRendah,myuskillRendah);
        double predikat24 = min(min47,min48);
        System.out.println("predikat 24 = "+predikat24);
        
        double min49 = min(myumuda,myutinggi);
        double min50 = min(myuresponTinggi,myuskillTinggi);
        double predikat25 = min(min49,min50);
        System.out.println("predikat 25 = "+predikat25);
        
        double min51 = min(myumuda,myutinggi);
        double min52 = min(myuresponTinggi,myuskillRendah);
        double predikat26 = min(min51,min52);
        System.out.println("predikat 26 = "+predikat26);
        
        double min53 = min(myumuda,myutinggi);
        double min54 = min(myuresponRendah,myuskillTinggi);
        double predikat27 = min(min53,min54);
        System.out.println("predikat 27 = "+predikat27);
        
        double min55 = min(myumuda,myutinggi);
        double min56 = min(myuresponRendah,myuskillRendah);
        double predikat28 = min(min55,min56);
        System.out.println("predikat 28 = "+predikat28);
        
        double min57 = min(myumuda,myusedang);
        double min58 = min(myuresponTinggi,myuskillTinggi);
        double predikat29 = min(min57,min58);
        System.out.println("predikat 29 = "+predikat29);
        
        double min59 = min(myumuda,myusedang);
        double min60 = min(myuresponTinggi,myuskillRendah);
        double predikat30 = min(min59,min60);
        System.out.println("predikat 30 = "+predikat30);
        
        double min61 = min(myumuda,myusedang);
        double min62 = min(myuresponRendah,myuskillTinggi);
        double predikat31 = min(min61,min62);
        System.out.println("predikat 31 = "+predikat31);
        
        double min63 = min(myumuda,myusedang);
        double min64 = min(myuresponRendah,myuskillRendah);
        double predikat32 = min(min63,min64);
        System.out.println("predikat 32 = "+predikat32);
        System.out.println("\n");
        
        double min65 = min(myumuda,myupendek);
        double min66 = min(myuresponTinggi,myuskillTinggi);
        double predikat33 = min(min65,min66);
        System.out.println("predikat 32 = "+predikat33);
        System.out.println("\n");
        
        double min67 = min(myumuda,myupendek);
        double min68 = min(myuresponTinggi,myuskillRendah);
        double predikat34 = min(min67,min68);
        System.out.println("predikat 34 = "+predikat34);
        System.out.println("\n");
        
        double min69 = min(myumuda,myupendek);
        double min70 = min(myuresponRendah,myuskillTinggi);
        double predikat35 = min(min69,min70);
        System.out.println("predikat 35 = "+predikat35);
        System.out.println("\n");
        
        double min71 = min(myumuda,myupendek);
        double min72 = min(myuresponRendah,myuskillRendah);
        double predikat36 = min(min71,min72);
        System.out.println("predikat 36 = "+predikat36);
        System.out.println("\n");
        
        double z1 = zproper(predikat1);
        System.out.println("Z1 = "+z1);

        double z2 = zproper(predikat2);
        System.out.println("Z2 = "+z2);

        double z3 = znonPorper(predikat3);
        System.out.println("Z3 = "+z3);

        double z4 = znonPorper(predikat4);
        System.out.println("Z4 = "+z4);

        double z5 = zproper(predikat5);
        System.out.println("Z5 = "+z5);

        double z6 = zproper(predikat6);
        System.out.println("Z6 = "+z6);

        double z7 = zproper(predikat7);
        System.out.println("Z7 = "+z7);

        double z8 = znonPorper(predikat8);
        System.out.println("Z8 = "+z8);

        double z9 = zproper(predikat9);
        System.out.println("Z9 = "+z9);

        double z10 = zproper(predikat10);
        System.out.println("Z10 = "+z10);

        double z11 = znonPorper(predikat11);
        System.out.println("Z11 = "+z11);

        double z12 = znonPorper(predikat12);
        System.out.println("Z12 = "+z12);

        double z13 = zproper(predikat13);
        System.out.println("Z13 = "+z13);

        double z14 = zproper(predikat14);
        System.out.println("Z14 = "+z14);

        double z15 = znonPorper(predikat15);
        System.out.println("Z15 = "+z15);

        double z16 = znonPorper(predikat16);
        System.out.println("Z16 = "+z16);

        double z17 = zproper(predikat17);
        System.out.println("Z17 = "+z17);

        double z18 = zproper(predikat18);
        System.out.println("Z18 = "+z18);

        double z19 = zproper(predikat19);
        System.out.println("Z19 = "+z19);

        double z20 = znonPorper(predikat20);
        System.out.println("Z20 = "+z20);

        double z21 = zproper(predikat21);
        System.out.println("Z21 = "+z21);

        double z22 = zproper(predikat22);
        System.out.println("Z22 = "+z22);

        double z23 = zproper(predikat23);
        System.out.println("Z23 = "+z23);

        double z24 = znonPorper(predikat24);
        System.out.println("Z24 = "+z24);

        double z25 = zproper(predikat25);
        System.out.println("Z25 = "+z25);

        double z26 = zproper(predikat26);
        System.out.println("Z26 = "+z26);

        double z27 = znonPorper(predikat27);
        System.out.println("Z27 = "+z27);

        double z28 = znonPorper(predikat28);
        System.out.println("Z28 = "+z28);

        double z29 = zproper(predikat29);
        System.out.println("Z29 = "+z29);

        double z30 = zproper(predikat30);
        System.out.println("Z30 = "+z30);

        double z31 = zproper(predikat31);
        System.out.println("Z31 = "+z31);

        double z32 = znonPorper(predikat32);
        System.out.println("Z32 = "+z32);

        double z33 = zproper(predikat33);
        System.out.println("Z33 = "+z33);

        double z34 = zproper(predikat34);
        System.out.println("Z34 = "+z34);

        double z35 = znonPorper(predikat35);
        System.out.println("Z35 = "+z35);

        double z36 = znonPorper(predikat36);
        System.out.println("Z36 = "+z36);

        System.out.println("\n");
        
      
        

        double zTot = ((predikat1*z1)+(predikat2*z2)+(predikat3*z3)+(predikat4*z4)
                +(predikat5*z5)+(predikat6*z6)+(predikat7*z7)+(predikat8*z8)+(predikat9*z9)
                +(predikat10*z10)+(predikat11*z11)+(predikat12*z12)+(predikat13*z13)+(predikat14*z14)
                +(predikat15*z15)+(predikat16*z16)+(predikat17*z17)+(predikat18*z18)+(predikat19*z19)
                +(predikat20*z20)+(predikat21*z21)+(predikat22*z22)+(predikat23*z23)+(predikat24*z24)
                +(predikat25*z25)+(predikat26*z26)+(predikat27*z27)+(predikat28*z28)+(predikat29*z29)
                +(predikat30*z30)+(predikat31*z31)+(predikat32*z32)+(predikat33*z33)+(predikat34*z34)
                +(predikat35*z35)+(predikat36*z36))/(predikat1+predikat2+predikat3+predikat4
                +predikat5+predikat6+predikat7+predikat8+predikat9+predikat10+predikat11+predikat12
                +predikat13+predikat14+predikat15+predikat16+predikat17+predikat18+predikat19+predikat20
                +predikat21+predikat22+predikat23+predikat24+predikat25+predikat26+predikat27+predikat28
                +predikat29+predikat30+predikat31+predikat32+predikat33+predikat34+predikat35+predikat36);
        System.out.println("Z Total = "+zTot);


        return zTot;
  
      
    }
}
